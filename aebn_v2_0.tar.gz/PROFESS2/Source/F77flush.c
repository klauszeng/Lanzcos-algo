// This is a small c program that simply flushes the file output buffers.

#include <stdio.h>
int f77flush_()
{
fflush(NULL);
return 0;
}

